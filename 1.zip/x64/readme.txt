This is x64 version of unrar.dll.
