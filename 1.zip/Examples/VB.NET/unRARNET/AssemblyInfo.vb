Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("UnRARNET")> 
<Assembly: AssemblyDescription("UnRAR Wrapper Class")> 
<Assembly: AssemblyCompany("ajm Software")> 
<Assembly: AssemblyProduct("UnRAR")> 
<Assembly: AssemblyCopyright("Copyright � 2004 ajm Software L.L.C. All rights reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 
'<Assembly: AssemblyKeyFileAttribute("E:\MyProjects\ajmsoft.snk")> 
'<Assembly: AssemblyDelaySign(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("EF0469C5-BEB1-4FC6-B460-511B0826B8DB")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
