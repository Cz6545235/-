For an open source application written in Perl which uses unrar.dll, visit:
    http://unrarextractrec.sourceforge.net/
    http://sourceforge.net/projects/unrarextractrec/
