C sample for unrar.dll library.

Compile UnRDLL.c as Windows console application to build UnRDLL.exe.
Add unrar.h to current directory before compiling.
