All samples except C sample (UnRDLL.c) are contributed by unrar.dll users.
Many of them are obsolete and can be incompatible with latest unrar.dll API.

We at rarlab.com created and tested only UnRDLL.c sample.
It is modified according to all API changes.

